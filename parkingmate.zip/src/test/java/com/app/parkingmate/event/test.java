package com.app.parkingmate.event;

import com.app.parkingmate.domain.VO.EventVO;
import com.app.parkingmate.mapper.EventMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.sql.Date;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

@SpringBootTest
@Slf4j
public class test {
    @Autowired
    private EventMapper eventMapper;

    @Test
    public void insertTest(){
        EventVO eventVO = new EventVO();
        eventVO.setEventContent("테스트 내용1");
        eventVO.setEventTitle("테스트 제목1");
        eventVO.setEventStatus("0");
        eventVO.setEventStartDate(Date.valueOf("2023-10-01"));
        eventVO.setEventEndDate(Date.valueOf("2023-11-01"));
        eventMapper.insert(eventVO);
    }

    @Test
    public void updateTest(){
        EventVO eventVO = new EventVO();
        eventVO.setEventId(1);
        eventVO.setEventContent("수정 테스트 내용1");
        eventVO.setEventTitle("수정 테스트 제목1");
        eventVO.setEventStatus("0");
        eventVO.setEventStartDate(Date.valueOf("2023-10-01"));
        eventVO.setEventEndDate(Date.valueOf("2023-11-01"));

        eventMapper.update(eventVO);

    }

    @Test
    public void selectAllTest(){
        eventMapper.selectAll().stream().map(EventVO::toString).forEach(log::info);
    }

}
