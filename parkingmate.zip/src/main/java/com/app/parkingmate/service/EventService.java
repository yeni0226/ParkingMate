package com.app.parkingmate.service;

import com.app.parkingmate.domain.VO.EventVO;

import java.util.List;

public interface EventService {
// 이벤트 작성
    public void create(EventVO eventVO);

//    이벤트 리스트

    List<EventVO> list();

    //    이벤트 수정
    public void update(EventVO eventVO);

//    이벤트 status 수정
    public void updateStatus(EventVO eventVO);
}
