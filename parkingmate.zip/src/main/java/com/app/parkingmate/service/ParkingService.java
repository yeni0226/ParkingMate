package com.app.parkingmate.service;

public interface ParkingService {
}
