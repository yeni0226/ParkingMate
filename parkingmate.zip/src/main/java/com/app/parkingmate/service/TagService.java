package com.app.parkingmate.service;

public interface TagService {
}
