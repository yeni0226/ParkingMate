package com.app.parkingmate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParkingmateApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParkingmateApplication.class, args);
	}

}
